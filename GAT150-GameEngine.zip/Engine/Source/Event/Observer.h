#pragma once


class Observer
{
public:
	virtual ~Observer();
	
};