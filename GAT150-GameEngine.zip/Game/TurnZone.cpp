#include "TurnZone.h"

void TurnZone::Initialize()
{
	//
}

void TurnZone::Update(float dt)
{
	//
}


void TurnZone::Read(const json_t& value)
{
	READ_DATA(value, uncertainty);
}

void TurnZone::Write(json_t& value)
{
	//
}